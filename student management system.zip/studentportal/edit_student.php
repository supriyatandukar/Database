<?php
session_start();
include("dbexamconnect.php");

//Redirect if not logged in
if (!isset($_SESSION['id'])) {
    header("Location: logindb.php");
    exit();
}

//Validate and get student ID from URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Student ID is required.";
    exit();
}

$id = (int)$_GET['id'];

//Fetch student data
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();

if (!$student) {
    echo "Student not found.";
    exit();
}

//Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $full_name = $_POST['full_name'] ?? '';
    $email     = $_POST['email'] ?? '';
    $phone     = $_POST['phone'] ?? '';
    $course    = $_POST['course'] ?? '';
    $profile_pic = $student['profile_pic']; // Default to old pic

    //Handle profile picture update
    if (!empty($_FILES['profile_pic']['name'])) {
        // Delete old picture
        if (!empty($student['profile_pic']) && file_exists("uploads/" . $student['profile_pic'])) {
            unlink("uploads/" . $student['profile_pic']);
        }

        $ext = pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION);
        $profile_pic = uniqid('student_') . '.' . $ext;
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], "uploads/" . $profile_pic);
    }

    //Update student info
    $stmt = $conn->prepare("UPDATE students SET full_name=?, email=?, phone=?, course=?, profile_pic=? WHERE id=?");
    $stmt->bind_param("sssssi", $full_name, $email, $phone, $course, $profile_pic, $id);

    if ($stmt->execute()) {
        header("Location: dashboarddb.php?updated=1");
        exit();
    } else {
        echo "Error updating record: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f2f5;
            padding: 2rem;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }
        h2 {
            color: #002b5c;
        }
        label {
            display: block;
            margin-top: 1rem;
            font-weight: 600;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 0.4rem;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        button {
            margin-top: 1.5rem;
            padding: 12px 20px;
            background-color: #004080;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        button:hover {
            background-color: #003366;
        }
        img.preview {
            width: 100px;
            margin-top: 0.5rem;
            border-radius: 50%;
            border: 2px solid #002b5c;
        }
        .back-link {
            display: inline-block;
            margin-top: 1rem;
            text-decoration: none;
            color: #004080;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Student Profile</h2>
    <form method="POST" enctype="multipart/form-data">
        <label for="full_name">Full Name:</label>
        <input type="text" name="full_name" value="<?= htmlspecialchars($student['full_name']) ?>" required>

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" required>

        <label for="phone">Phone:</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($student['phone']) ?>" required>

        <label for="course">Course:</label>
        <select name="course" required>
            <option value="BSc CS" <?= $student['course'] === 'BSc CS' ? 'selected' : '' ?>>BSc CS</option>
            <option value="BIT" <?= $student['course'] === 'BIT' ? 'selected' : '' ?>>BIT</option>
            <option value="BIM" <?= $student['course'] === 'BIM' ? 'selected' : '' ?>>BIM</option>
            <option value="BCA" <?= $student['course'] === 'BCA' ? 'selected' : '' ?>>BCA</option>
        </select>

        <label for="profile_pic">Profile Picture:</label>
        <input type="file" name="profile_pic" accept="image/*">
        <?php if (!empty($student['profile_pic'])): ?>
            <img src="uploads/<?= htmlspecialchars($student['profile_pic']) ?>" alt="Current Photo" class="preview">
        <?php endif; ?>

        <button type="submit">Update Profile</button>
    </form>

    <a href="dashboarddb.php" class="back-link">← Back to Dashboard</a>
</div>

</body>
</html>
