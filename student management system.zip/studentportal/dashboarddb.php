<?php
session_start();
include("dbexamconnect.php");

if (!isset($_SESSION['id'])) {
    echo "<script>alert('Please log in first.'); window.location.href='logindb.php';</script>";
    exit();
}

$id = $_SESSION['id'];
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background: #f4f6f8;
      color: #333;
    }

    header {
      background: #002b5c;
      color: white;
      padding: 1rem 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    header h2 {
      display: flex;
      align-items: center;
      margin: 0;
      font-size: 1.5rem;
    }

    header img {
      height: 40px;
      margin-right: 10px;
    }

    nav a {
      color: white;
      text-decoration: none;
      margin-left: 1.5rem;
    }

    nav a:hover {
      text-decoration: underline;
    }

    main {
      max-width: 800px;
      margin: 2rem auto;
      background: #fff;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    }

    .profile-header {
      display: flex;
      align-items: center;
      gap: 20px;
      margin-bottom: 1.5rem;
    }

    .profile-header img {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid #002b5c;
    }

    .profile-info p {
      margin: 8px 0;
      font-size: 1rem;
    }

    h1 {
      color: #002b5c;
      margin-bottom: 1.5rem;
    }

    .button-bar {
      margin-top: 2rem;
      display: flex;
      justify-content: space-between;
    }

    .button-bar a {
      text-decoration: none;
      padding: 10px 18px;
      background-color: #004080;
      color: white;
      border-radius: 6px;
      font-weight: 500;
    }

    .button-bar a.delete {
      background-color: crimson;
    }

    @media (max-width: 600px) {
      .profile-header {
        flex-direction: column;
        text-align: center;
      }

      .profile-header img {
        width: 100px;
        height: 100px;
      }

      .button-bar {
        flex-direction: column;
        gap: 1rem;
        align-items: center;
      }
    }
  </style>
</head>
<body>

<header>
  <div style="display: flex; align-items: center;">
    <img src="studentportal.png" alt="Logo">
    <h2>Student Portal</h2>
  </div>
  <nav>
    <a href="index.php">Home</a>
    <a href="logout.php">Logout</a>
  </nav>
</header>

<main>
  <h1>Hello, <?= htmlspecialchars($user['full_name']) ?></h1>

  <div class="profile-header">
    <img src="<?= $user['profile_pic'] ? 'uploads/' . $user['profile_pic'] : 'default-profile.jpg' ?>" alt="Profile Photo">
    <div class="profile-info">
      <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
      <p><strong>Phone:</strong> <?= htmlspecialchars($user['phone']) ?></p>
      <p><strong>Course:</strong> <?= htmlspecialchars($user['course']) ?></p>
    </div>
  </div>

  <div class="button-bar">
    <a href="edit_student.php?id=<?= $user['id'] ?>">Update Profile</a>
    <a href="delete.php?id=<?= $user['id'] ?>" class="delete" onclick="return confirm('Are you sure you want to delete your account?');">Delete Account</a>
  </div>
</main>

</body>
</html>
