<?php
session_start();
include("dbexamconnect.php");

if (!isset($_SESSION['id'])) {
    header("Location: logindb.php");
    exit();
}

$id = $_GET['id'] ?? null;

if (!$id || !is_numeric($id)) {
    echo "Invalid request.";
    exit();
}

if ($_SESSION['id'] != $id) {
    echo "Unauthorized access.";
    exit();
}

$stmt = $conn->prepare("SELECT profile_pic FROM students WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user && !empty($user['profile_pic']) && file_exists("uploads/" . $user['profile_pic'])) {
    unlink("uploads/" . $user['profile_pic']);
}

$stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
$stmt->bind_param("i", $id);
if ($stmt->execute()) {
    session_destroy();
    echo "<script>alert('Your account has been deleted.'); window.location='indexdb.php';</script>";
    exit();
} else {
    echo "Error deleting account.";
}
?>
