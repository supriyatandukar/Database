<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "db_exam";
$port = 3307;   

$conn = mysqli_connect($servername, $username, $password, $dbname, $port);

if (!$conn) {
    die("Could not connect! Error: " . mysqli_connect_error());
}
