<?php
include("dbexamconnect.php");

$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST["full_name"]);
    $email = trim($_POST["email"]);
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $phone = trim($_POST["phone"]);
    $course = trim($_POST["course"]);

    $profile_pic_name = "";

    // Handle profile picture upload
    if (!empty($_FILES["profile_pic"]["name"])) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir); // create folder if not exists

        $file_tmp = $_FILES["profile_pic"]["tmp_name"];
        $file_name = basename($_FILES["profile_pic"]["name"]);
        $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        // Generate unique filename
        $profile_pic_name = uniqid() . "." . $ext;
        $target_file = $target_dir . $profile_pic_name;

        if (!in_array($ext, ["jpg", "jpeg", "png", "gif"])) {
            $error = "Only image files are allowed (jpg, jpeg, png, gif).";
        } else {
            move_uploaded_file($file_tmp, $target_file);
        }
    }

    if (empty($error)) {
        $stmt = $conn->prepare("INSERT INTO students (email, password, full_name, phone, course, profile_pic) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $email, $password, $full_name, $phone, $course, $profile_pic_name);

        if ($stmt->execute()) {
            $success = "Registration successful! You can now <a href='logindb.php'>login here</a>.";
        } else {
            $error = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Student Portal</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f6f8;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 3rem 1rem;
        }
        .form-container {
            background-color: #fff;
            padding: 2rem 2.5rem;
            border-radius: 10px;
            box-shadow: 0 0 12px rgba(0,0,0,0.08);
            width: 400px;
        }
        h2 {
            text-align: center;
            color: #002b5c;
            margin-bottom: 1.5rem;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="file"] {
            width: 100%;
            padding: 0.7rem;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1rem;
        }
        button {
            width: 100%;
            padding: 0.8rem;
            background-color: #004080;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            cursor: pointer;
        }
        button:hover {
            background-color: #003366;
        }
        .message {
            text-align: center;
            margin-top: 1rem;
            font-size: 0.95rem;
        }
        .message.success {
            color: green;
        }
        .message.error {
            color: red;
        }
        .links {
            text-align: center;
            margin-top: 1rem;
        }
        .links a {
            color: #004080;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Student Registration</h2>
    <form method="POST" action="" enctype="multipart/form-data">
        <input type="text" name="full_name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="text" name="phone" placeholder="Phone Number" required>
        <input type="text" name="course" placeholder="Course" required>
        <input type="file" name="profile_pic" accept="image/*">

        <button type="submit">Register</button>
    </form>

    <?php if ($success): ?>
        <p class="message success"><?= $success ?></p>
    <?php elseif ($error): ?>
        <p class="message error"><?= $error ?></p>
    <?php endif; ?>

    <div class="links">
        <a href="logindb.php">← Already registered? Login here</a>
    </div>
</div>

</body>
</html>
