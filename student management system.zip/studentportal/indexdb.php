<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Welcome | Student Portal</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, sans-serif;
      background-color: #f5f7fa;
      color: #333;
    }

    header {
      background-color: #002b5c;
      color: white;
      padding: 1rem 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    header h1 {
      font-size: 1.7rem;
      margin: 0;
    }

    nav a {
      color: white;
      text-decoration: none;
      margin-left: 2rem;
      font-weight: bold;
    }

    nav a:hover {
      text-decoration: underline;
    }

    .hero {
      background: url('campus.jpg') center/cover no-repeat;
      padding: 5rem 2rem;
      color: white;
      text-align: center;
      background-blend-mode: multiply;
      background-color: rgba(0, 43, 92, 0.7);
    }

    .hero h2 {
      font-size: 2.5rem;
      margin-bottom: 1rem;
    }

    .hero p {
      font-size: 1.2rem;
      max-width: 700px;
      margin: auto;
    }

    main {
      max-width: 900px;
      margin: 3rem auto;
      padding: 2rem;
      background: white;
      border-radius: 10px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.05);
    }

    main h3 {
      color: #002b5c;
      font-size: 1.5rem;
      margin-bottom: 1rem;
    }

    main p {
      font-size: 1.05rem;
      line-height: 1.6;
    }

    footer {
      background: #e0e0e0;
      padding: 1rem;
      text-align: center;
      font-size: 0.95rem;
      margin-top: 4rem;
    }
  </style>
</head>
<body>

<header>
  <div style="display: flex; align-items: center;">
    <img src="studentportal.png" alt="Student Portal Logo" style="height: 45px; margin-right: 10px;">
    <h1>Student Portal</h1>
  </div>
  <nav>
    <a href="indexdb.php">Home</a>
    <a href="logindb.php">Login</a>
    <a href="dashboarddb.php">Dashboard</a>
  </nav>
</header>

<div class="hero">
  <h2>Welcome to the Student Portal</h2>
  <p>Your gateway to academic information, profile management, and student resources.</p>
</div>

<main>
  <h3>About the Portal</h3>
  <p>This portal provides students with access to their academic information in a secure and user-friendly environment. You can log in to view and update your profile, check your course details, and stay informed.</p>

  <p style="margin-top: 1.5rem;">
    Already have an account? <a href="logindb.php" style="color: #004080;">Log in here</a>. <br>
    New student? Contact the admin to register your credentials.
  </p>
</main>

<footer>
  &copy; <?= date("Y") ?> Student Portal. All rights reserved.
</footer>

</body>
</html>
