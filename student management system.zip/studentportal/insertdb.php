<?php
include("dbexamconnect.php"); // assuming this sets $conn

$email = 'supriya2301@gmail.com';
$password = password_hash('password123', PASSWORD_DEFAULT);
$full_name = 'Supriya Tandukar';
$phone = '1234567890';
$course = 'CS';

$stmt = $conn->prepare("INSERT INTO students (email, password, full_name, phone, course) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $email, $password, $full_name, $phone, $course);

if ($stmt->execute()) {
  echo "New student record created successfully";
} else {
  echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
