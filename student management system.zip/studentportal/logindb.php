<?php
session_start();
include("dbexamconnect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM students WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $user = $res->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['id'] = $user['id'];
            header("Location: dashboarddb.php");
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "Email not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Student Portal</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f6f8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background-color: #fff;
            padding: 2rem 2.5rem;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 350px;
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .login-container input {
            width: 100%;
            padding: 0.7rem;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1rem;
        }
        .login-container button {
            width: 100%;
            padding: 0.8rem;
            background-color: #004080;
            color: white;
            font-size: 1rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        .login-container button:hover {
            background-color: #003366;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-top: 1rem;
        }
        .links {
            text-align: center;
            margin-top: 1.5rem;
        }
        .links a {
            display: block;
            margin: 0.3rem 0;
            color: #004080;
            text-decoration: none;
            font-size: 0.95rem;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

<div class="login-container">
    <h2>Student Login</h2>
    <form method="POST" action="">
        <input type="email" name="email" required placeholder="Email">
        <input type="password" name="password" required placeholder="Password">
        <button type="submit">Login</button>
    </form>

    <?php if (isset($error)) echo "<p class='error-message'>$error</p>"; ?>

    <div class="links">
        <a href="registerdb.php">Don't have an account? Register here</a>
        <a href="indexdb.php">← Back to Home</a>
    </div>
</div>

</body>
</html>
